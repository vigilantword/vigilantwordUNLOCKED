var BUILD = "6.5.1-202611261834";
var CORE = "vw-core-" + BUILD, DATA = "vw-data";
var SHELL = ["./", "index.html", "assets/manifest.webmanifest", "assets/logo.jpg", "assets/splash.jpg", "assets/favicon.png", "assets/icon-180.png", "assets/icon-192.png", "assets/icon-512.png"];
var TEXT = ["assets/data/manifest.json", "assets/data/study.json", "assets/data/dict.json", "assets/data/names.json",
  "assets/packs/books-1.json", "assets/packs/books-2.json", "assets/packs/books-3.json", "assets/packs/books-4.json", "assets/packs/books-5.json", "assets/packs/books-6.json"];
function refresh(c, u){
  return c.match(u).then(function(hit){
    var tag = hit && hit.headers.get("ETag");
    var init = tag ? { headers: { "If-None-Match": tag }, cache: "no-store" } : { cache: "no-cache" };
    return fetch(u, init).then(function(r){
      if (r.status === 304) return;
      if (r.ok) return c.put(u, r);
    });
  }).catch(function(){});
}
self.addEventListener("install", function(e){
  e.waitUntil(Promise.all([
    caches.open(CORE).then(function(c){
      return Promise.all(SHELL.map(function(u){
        return fetch(new Request(u, { cache: "reload" })).then(function(r){ if (!r.ok) throw new Error(u); return c.put(u, r); });
      }));
    }),
    caches.open(DATA).then(function(c){
      return Promise.all(TEXT.map(function(u){ return refresh(c, u); }));
    })
  ]).then(function(){ return self.skipWaiting(); }));
});
self.addEventListener("activate", function(e){
  e.waitUntil(caches.keys().then(function(keys){
    return Promise.all(keys.filter(function(k){ return k.indexOf("vw-core-") === 0 && k !== CORE; }).map(function(k){ return caches.delete(k); }));
  }).then(function(){ return self.clients.claim(); }));
});
self.addEventListener("fetch", function(e){
  var req = e.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  var path = url.pathname;
  if (/\/assets\/version\.json$/.test(path) || path.indexOf("/assets/data/commentators/") >= 0) return;
  if (req.mode === "navigate" || /\/index\.html$/.test(path)){
    e.respondWith(fetch(req.url, { cache: "no-cache" }).then(function(r){
      if (r.ok){ var copy = r.clone(); caches.open(CORE).then(function(c){ c.put("index.html", copy); }); }
      return r;
    }).catch(function(){
      return caches.match("index.html", { ignoreSearch: true }).then(function(hit){ return hit || caches.match("./"); });
    }));
    return;
  }
  if (path.indexOf("/assets/") < 0) return;
  var store = /\/assets\/(data|packs|imgbg)\//.test(path) ? DATA : CORE;
  e.respondWith(caches.match(req, { ignoreSearch: true }).then(function(hit){
    var net = fetch(req).then(function(r){
      if (r.ok){ var copy = r.clone(); caches.open(store).then(function(c){ c.put(req, copy); }); }
      return r;
    });
    if (hit){ net.catch(function(){}); return hit; }
    return net;
  }));
});
self.addEventListener("notificationclick", function(e){
  e.notification.close();
  var target = (e.notification.data && e.notification.data.view) || "home";
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(function(list){
    for (var i = 0; i < list.length; i++){
      var c = list[i];
      if ("focus" in c){ c.postMessage({ vigilantWordView: target }); return c.focus(); }
    }
    if (self.clients.openWindow) return self.clients.openWindow("index.html");
  }));
});
